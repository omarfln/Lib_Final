package business;

import java.io.Serializable;
import java.util.Date;

public class CheckoutCopyRecord implements Serializable {
    private static final long serialVersionUID = -63976228084869815L;

    private String id;

    @Override
    public String toString() {
        return "CheckoutCopyRecord{" +
                "id='" + id + '\'' +
                ", copy=" + copy +
                ", member=" + member +
                ", landingDate=" + landingDate +
                ", dueDate=" + dueDate +
                '}';
    }

    private BookCopy copy;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    private LibraryMember member;

    private Date landingDate;
    private Date dueDate;

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public BookCopy getCopy() {
        return copy;
    }

    public LibraryMember getMember() {
        return member;
    }

    public void setMember(LibraryMember member) {
        this.member = member;
    }

    public Date getLandingDate() {
        return landingDate;
    }

    public CheckoutCopyRecord(BookCopy copy, LibraryMember member) {
        this.id = "" + (int) Math.floor(Math.random() * 10000);
        this.copy = copy;
        this.member = member;
        this.landingDate = new Date();
        Date _dueDate = new Date(landingDate.getTime());
        _dueDate.setDate(_dueDate.getDate() + copy.getBook().getMaxCheckoutLength());
        this.dueDate = _dueDate;
    }

    public void setLandingDate(Date landingDate) {
        this.landingDate = landingDate;
    }

    public void setCopy(BookCopy copy) {
        this.copy = copy;
    }

    public boolean isOverDue() {
        return (new Date().after(dueDate));
    }

}
