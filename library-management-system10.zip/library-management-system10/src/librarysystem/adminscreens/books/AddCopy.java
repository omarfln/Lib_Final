package librarysystem.adminscreens.books;

import business.LibrarySystemException;
import controllers.ControllerInterface;
import controllers.SystemController;
import librarysystem.LibWindow;

import javax.swing.*;
import java.awt.*;

public class AddCopy extends JPanel implements LibWindow {

    public static final AddCopy INSTANCE = new AddCopy();
    ControllerInterface ci = new SystemController();
    private boolean isInitialized = false;

    private javax.swing.JButton addCopyBtn;
    private javax.swing.JTextField isbnField;
    private javax.swing.JLabel isbnLabel;
    private javax.swing.JLabel jLabel2;

    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        isbnLabel = new javax.swing.JLabel();
        isbnField = new javax.swing.JTextField();
        addCopyBtn = new javax.swing.JButton();

        jLabel2.setFont(new java.awt.Font("Arial Black", 0, 18));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Add Copy Of An Existing Book ");
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        isbnLabel.setText("ISBN");
        isbnLabel.setToolTipText("");

        addCopyBtn.setText("Add Copy");
        addCopyBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCopyBtnActionPerformed(evt);
            }
        });

        JPanel panel = new JPanel();
        panel.setSize(600, 600);
        panel.setBackground(new Color(243, 248, 246));

        GroupLayout layout = new GroupLayout(panel);
        panel.setLayout(layout);
        this.add(panel);

        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addContainerGap()
                                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 715,
                                                        Short.MAX_VALUE))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(76, 76, 76)
                                                .addComponent(isbnLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 69,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(18, 18, 18)
                                                .addComponent(isbnField, javax.swing.GroupLayout.PREFERRED_SIZE, 216,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(33, 33, 33)
                                                .addComponent(addCopyBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 118,
                                                        javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(0, 0, Short.MAX_VALUE)))
                                .addContainerGap()));
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jLabel2)
                                .addGap(42, 42, 42)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(isbnLabel)
                                        .addComponent(isbnField, javax.swing.GroupLayout.PREFERRED_SIZE,
                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(addCopyBtn))
                                .addContainerGap(454, Short.MAX_VALUE)));
    }

    private void addCopyBtnActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            ci.addCopyofAnExistingBook(isbnField.getText());
            JOptionPane.showMessageDialog(this, "Copy added successfully", "", JOptionPane.INFORMATION_MESSAGE);
        } catch (LibrarySystemException e) {
            JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @Override
    public void init() {
        if (!isInitialized) {
            initComponents();
            isInitialized = true;
        } else {
            isbnField.setText("");
        }

    }

    @Override
    public boolean isInitialized() {
        return false;
    }

    @Override
    public void isInitialized(boolean val) {

    }
}
