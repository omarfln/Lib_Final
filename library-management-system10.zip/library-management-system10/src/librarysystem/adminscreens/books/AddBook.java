package librarysystem.adminscreens.books;

import business.Author;
import business.LibrarySystemException;
import controllers.ControllerInterface;
import controllers.SystemController;
import librarysystem.LibWindow;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Vector;

public class AddBook extends JPanel implements LibWindow {

        public static final AddBook INSTANCE = new AddBook();
        ControllerInterface ci = new SystemController();
        private boolean isInitialized = false;
        private javax.swing.JTextField ISBField;
        private javax.swing.JButton addAutherBtn;
        private javax.swing.JLabel autherLabel;
        private javax.swing.JList<String> authersList;
        private javax.swing.JTextField cityField;
        private javax.swing.JLabel cityLabel;
        private javax.swing.JTextField copiesField;
        private javax.swing.JLabel copiesLabel;
        private javax.swing.JTextField firstNameField;
        private javax.swing.JLabel firstNameLabel;
        private javax.swing.JLabel isbnLabel;
        private javax.swing.JComboBox<String> jComboBox1;
        private javax.swing.JLabel jLabel2;
        private javax.swing.JScrollPane jScrollPane1;
        private javax.swing.JTextField lastNameField;
        private javax.swing.JLabel lastNameLabel;
        private javax.swing.JSpinner maxCopiesField;
        private javax.swing.JLabel maxCopiesLabel;
        private javax.swing.JTextField phoneField;
        private javax.swing.JLabel phoneLabel;
        private javax.swing.JButton saveBookBtn;
        private javax.swing.JLabel stateLabel;
        private javax.swing.JTextField streetField;
        private javax.swing.JLabel streetLabel;
        private javax.swing.JTextField titleField;
        private javax.swing.JLabel titleLabel;
        private javax.swing.JTextField zipCodeField;
        private javax.swing.JLabel zipCodeLabel;

        private javax.swing.JTextField bioField;
        private javax.swing.JLabel bioLabel;

        private JSpinner jSpinner1;

        private java.util.List<Author> authers = new ArrayList<>();

        private void initComponents() {

                jLabel2 = new javax.swing.JLabel();
                isbnLabel = new javax.swing.JLabel();
                ISBField = new javax.swing.JTextField();
                titleLabel = new javax.swing.JLabel();
                titleField = new javax.swing.JTextField();
                copiesLabel = new javax.swing.JLabel();
                copiesField = new javax.swing.JTextField();
                maxCopiesLabel = new javax.swing.JLabel();
                jScrollPane1 = new javax.swing.JScrollPane();
                authersList = new javax.swing.JList<>();
                autherLabel = new javax.swing.JLabel();
                jComboBox1 = new javax.swing.JComboBox<>();
                phoneLabel = new javax.swing.JLabel();
                zipCodeLabel = new javax.swing.JLabel();
                phoneField = new javax.swing.JTextField();
                zipCodeField = new javax.swing.JTextField();
                streetLabel = new javax.swing.JLabel();
                streetField = new javax.swing.JTextField();
                cityLabel = new javax.swing.JLabel();
                cityField = new javax.swing.JTextField();
                firstNameLabel = new javax.swing.JLabel();
                lastNameField = new javax.swing.JTextField();
                lastNameLabel = new javax.swing.JLabel();
                firstNameField = new javax.swing.JTextField();
                stateLabel = new javax.swing.JLabel();
                addAutherBtn = new javax.swing.JButton();
                saveBookBtn = new javax.swing.JButton();
                jSpinner1 = new javax.swing.JSpinner();
                bioLabel = new javax.swing.JLabel();
                bioField = new javax.swing.JTextField();

                jLabel2.setFont(new java.awt.Font("Arial Black", 0, 18));
                jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
                jLabel2.setText("Add Book");
                jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

                isbnLabel.setText("ISBN");

                titleLabel.setText("Title");

                copiesLabel.setText("Copies");

                maxCopiesLabel.setText("Max checkout length");

                jScrollPane1.setViewportView(authersList);

                autherLabel.setText("Author(s)");

                jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AL", "AK", "AS", "AZ", "AR",
                                "CA", "CO", "CT", "DE", "DC", "FL", "GA", "GU", "HI", "ID", "IL", "IN", "IA", "KS",
                                "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
                                "NM", "NY", "NC", "ND", "MP", "OH", "OK", "OR", "PA", "PR", "RI", "SC", "SD", "TN",
                                "TX", "UT", "VT", "VA", "VI", "WA", "WV", "WI", "WY", }));

                phoneLabel.setText("Phone");

                zipCodeLabel.setText("Zip Code");

                phoneField.setToolTipText("");

                zipCodeField.setToolTipText("");

                streetLabel.setText("Street");

                streetField.setToolTipText("");

                cityLabel.setText("City");

                cityField.setToolTipText("");

                firstNameLabel.setText("First Name");

                lastNameField.setToolTipText("");

                lastNameLabel.setText("Last Name");

                firstNameField.setToolTipText("");

                stateLabel.setText("State");

                addAutherBtn.setText("Add Auther");
                addAutherBtn.setActionCommand("");
                addAutherBtn.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                addAutherBtnActionPerformed(evt);
                        }
                });

                saveBookBtn.setText("Save Book");
                saveBookBtn.setActionCommand("");
                saveBookBtn.addActionListener(new java.awt.event.ActionListener() {
                        public void actionPerformed(java.awt.event.ActionEvent evt) {
                                saveBookBtnActionPerformed(evt);
                        }
                });

                bioLabel.setText("BIO");

                JPanel panel = new JPanel();
                panel.setSize(600, 600);
                panel.setBackground(new Color(243, 248, 246));

                GroupLayout layout = new GroupLayout(panel);
                panel.setLayout(layout);
                this.add(panel);
                layout.setHorizontalGroup(
                                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
                                                                                                layout.createSequentialGroup()
                                                                                                                .addGap(17, 17, 17)
                                                                                                                .addComponent(jLabel2,
                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                Short.MAX_VALUE))
                                                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING,
                                                                                                layout.createSequentialGroup()
                                                                                                                .addGap(66, 66, 66)
                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                javax.swing.GroupLayout.Alignment.TRAILING)
                                                                                                                                                                .addComponent(copiesLabel)
                                                                                                                                                                .addComponent(isbnLabel)
                                                                                                                                                                .addComponent(autherLabel))
                                                                                                                                                .addPreferredGap(
                                                                                                                                                                javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING,
                                                                                                                                                                                                false)
                                                                                                                                                                                                .addComponent(ISBField)
                                                                                                                                                                                                .addComponent(copiesField,
                                                                                                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                                                                                                137,
                                                                                                                                                                                                                Short.MAX_VALUE))
                                                                                                                                                                                .addGap(58, 58, 58)
                                                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                                                javax.swing.GroupLayout.Alignment.TRAILING)
                                                                                                                                                                                                .addComponent(titleLabel)
                                                                                                                                                                                                .addComponent(maxCopiesLabel))
                                                                                                                                                                                .addPreferredGap(
                                                                                                                                                                                                javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                                                                                                                                .addComponent(titleField,
                                                                                                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                                                                                                                169,
                                                                                                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                                                                                                                .addComponent(jSpinner1,
                                                                                                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                                                                                                                                .addComponent(jScrollPane1,
                                                                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                                                                                120,
                                                                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                javax.swing.GroupLayout.Alignment.TRAILING)
                                                                                                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                                                                                                .addComponent(firstNameLabel)
                                                                                                                                                                                .addGap(18, 18, 18)
                                                                                                                                                                                .addComponent(firstNameField,
                                                                                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                                                                                                150,
                                                                                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                                                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                                                javax.swing.GroupLayout.Alignment.TRAILING)
                                                                                                                                                                                                .addComponent(streetLabel)
                                                                                                                                                                                                .addComponent(phoneLabel)
                                                                                                                                                                                                .addComponent(stateLabel))
                                                                                                                                                                                .addGap(45, 45, 45)
                                                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                                                javax.swing.GroupLayout.Alignment.TRAILING,
                                                                                                                                                                                                false)
                                                                                                                                                                                                .addComponent(phoneField,
                                                                                                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                                                                                                                                .addComponent(streetField,
                                                                                                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                                                                                                                                .addComponent(jComboBox1,
                                                                                                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING,
                                                                                                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                                                                                                                150,
                                                                                                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))))
                                                                                                                                                .addGap(42, 42, 42)
                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                                                                                                .addComponent(lastNameLabel)
                                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                                javax.swing.GroupLayout.Alignment.TRAILING)
                                                                                                                                                                                .addComponent(cityLabel)
                                                                                                                                                                                .addComponent(zipCodeLabel)
                                                                                                                                                                                .addComponent(bioLabel)))
                                                                                                                                                .addGap(18, 18, 18)
                                                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING,
                                                                                                                                                                false)
                                                                                                                                                                .addComponent(lastNameField,
                                                                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                                                                150,
                                                                                                                                                                                Short.MAX_VALUE)
                                                                                                                                                                .addComponent(zipCodeField,
                                                                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                                                                150,
                                                                                                                                                                                Short.MAX_VALUE)
                                                                                                                                                                .addComponent(cityField,
                                                                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                                                                150,
                                                                                                                                                                                Short.MAX_VALUE)
                                                                                                                                                                .addComponent(bioField))))
                                                                                                                .addGap(4, 16, Short.MAX_VALUE)
                                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                                                                .addComponent(saveBookBtn)
                                                                                                                                .addComponent(addAutherBtn))
                                                                                                                .addGap(90, 90, 90)))
                                                                .addContainerGap()));
                layout.setVerticalGroup(
                                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(layout.createSequentialGroup()
                                                                .addContainerGap()
                                                                .addComponent(jLabel2)
                                                                .addGap(32, 32, 32)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                                                .addComponent(isbnLabel)
                                                                                .addComponent(ISBField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(titleLabel)
                                                                                .addComponent(titleField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGap(4, 4, 4)
                                                                .addComponent(saveBookBtn)
                                                                .addGap(1, 1, 1)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                                                .addComponent(copiesLabel)
                                                                                .addComponent(copiesField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(maxCopiesLabel)
                                                                                .addComponent(jSpinner1,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGap(19, 19, 19)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                .addComponent(jScrollPane1,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                58,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(autherLabel))
                                                                .addGap(18, 18, 18)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                                                .addComponent(lastNameField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(lastNameLabel)
                                                                                .addComponent(firstNameLabel)
                                                                                .addComponent(firstNameField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.LEADING)
                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                .addGap(18, 18, 18)
                                                                                                .addGroup(layout.createParallelGroup(
                                                                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                                                                                .addComponent(phoneLabel)
                                                                                                                .addComponent(phoneField,
                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                                                .addComponent(bioLabel)
                                                                                                                .addComponent(bioField,
                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)))
                                                                                .addGroup(layout.createSequentialGroup()
                                                                                                .addGap(26, 26, 26)
                                                                                                .addComponent(addAutherBtn)))
                                                                .addGap(19, 19, 19)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                                                .addComponent(streetLabel)
                                                                                .addComponent(streetField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(cityField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(cityLabel))
                                                                .addPreferredGap(
                                                                                javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                                .addGroup(layout.createParallelGroup(
                                                                                javax.swing.GroupLayout.Alignment.BASELINE)
                                                                                .addComponent(stateLabel)
                                                                                .addComponent(jComboBox1,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE)
                                                                                .addComponent(zipCodeLabel)
                                                                                .addComponent(zipCodeField,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE,
                                                                                                javax.swing.GroupLayout.DEFAULT_SIZE,
                                                                                                javax.swing.GroupLayout.PREFERRED_SIZE))
                                                                .addContainerGap(44, Short.MAX_VALUE)));

        }

        @Override
        public void init() {

                if (!isInitialized) {
                        initComponents();
                        isInitialized = true;
                        jSpinner1.setValue(1);
                } else {
                        clearFields();
                }

        }

        @Override
        public boolean isInitialized() {
                return false;
        }

        @Override
        public void isInitialized(boolean val) {

        }

        private void clearFields() {

                firstNameField.setText("");
                lastNameField.setText("");
                phoneField.setText("");
                streetField.setText("");
                cityField.setText("");
                authersList.removeAll();
                zipCodeField.setText("");
                ISBField.setText("");
                copiesField.setText("");

                authers.clear();
                jSpinner1.setValue(1);

        }

        private void saveBookBtnActionPerformed(java.awt.event.ActionEvent evt) {
                Integer myint = (Integer) jSpinner1.getValue();

                try {
                        ci.addBook(ISBField.getText(), titleField.getText(), myint, authers);
                        JOptionPane.showMessageDialog(this, "Book successfully added", "",
                                        JOptionPane.INFORMATION_MESSAGE);
                } catch (LibrarySystemException e) {
                        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                }

        }

        private void addAutherBtnActionPerformed(java.awt.event.ActionEvent evt) {
                Vector<String> v = new Vector<String>();
                Author author = ci.addAuthor(firstNameField.getText(), lastNameField.getText(), titleField.getText(),
                                streetField.getText(), cityField.getText(), jComboBox1.getSelectedItem().toString(),
                                zipCodeField.getText(), bioField.getText());
                authers.add(author);
                for (Author a : authers) {
                        v.add(a.getFirstName() + "  " + a.getLastName());

                }
                authersList.removeAll();
                authersList.setListData(v);

        }

}
